package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.model.Complaint;
import com.example.model.User;

@Transactional
@Component
public class ComplaintDao {

	@Autowired
	public SessionFactory _sessionFactory;

	public Session getSession() {
		System.out.println("session==>" + _sessionFactory.getCurrentSession());
		return _sessionFactory.getCurrentSession();
	}

	public Complaint insertComplaint(Complaint complaint,User user) {
		// TODO Auto-generated method stub
		Session session = this._sessionFactory.getCurrentSession();

		//getSession().save(complaint);
		session.save(user);
		complaint.setUser(user);
		session.save(complaint);
		return complaint;

	}

	@SuppressWarnings("unchecked")
	public List<Complaint> getAllComplaints() {
		Session session = this._sessionFactory.getCurrentSession();
		List<Complaint> complaintList = session.createQuery("from Complaint").list();
		for (Complaint c : complaintList) {
			System.out.println(c);
		}

		return complaintList;
	}

	public void test() {
		Session session = this._sessionFactory.getCurrentSession();
		User user = new User();
//		user.setUserId(1);
//		user.setUserEmail("mok@ghj.df");
//		user.setUserAddress("xcc");
//		user.setUserName("mok");
//		user.setUserNumber(522);
		session.save(user);
		Complaint complaint = new Complaint();
//		complaint.setComplaintId(2);
//		complaint.setComplaintType("Water");
//		complaint.setComplaintDesc("fgf");
		
		complaint.setUser(user);
		session.save(complaint);
	}
	
	@SuppressWarnings("deprecation")
	public void accept(Complaint com) {
		// TODO Auto-generated method stub
		Session session = this._sessionFactory.getCurrentSession();

		int id = com.getComplaintId();
		System.out.println("From Accept method"+id);
		Query query =(Query) getSession().createQuery("update Complaint set status=:status where complaintId=:id");
		
		//String hql = "update Complaint set status=:status"+"where complaintId=:id";
		//Query query = session.createQuery(hql);
		query.setParameter("status", "Approved");
		query.setParameter("id", id);
		int result = query.executeUpdate();
		
		
	}

	public void reject(Complaint com) {
		Session session = this._sessionFactory.getCurrentSession();

		int id = com.getComplaintId();
		System.out.println("From Reject method"+id);
		Query query =(Query) getSession().createQuery("update Complaint set status=:status where complaintId=:id");
		
		
		query.setParameter("status", "Rejected");
		query.setParameter("id", id);
		int result = query.executeUpdate();
				
	}
	
}
