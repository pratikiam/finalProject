package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class User {
	@Id  
 	@GeneratedValue
	private int userId;
	private String userName;
	private String userPassword;
	private long  userNumber;
	private String userAddress;
	private String userEmail;
	
//private List<Complaint> complaintList= new ArrayList<Complaint>();
//	
//
//	public List<Complaint> getAllComplaints() 
//	{
//		return complaintList;
//	}
//	
//	public void setComplaint(List<Complaint> complaintList) 
//	{
//		this.complaintList = complaintList;
//	}
	
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public long getUserNumber() {
		return userNumber;
	}
	public void setUserNumber(long userNumber) {
		this.userNumber = userNumber;
	}
	public String getUserAddress() {
		return userAddress;
	}
	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public User(int userId, String userName, String userPassword, long userNumber, String userAddress,
			String userEmail) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userNumber = userNumber;
		this.userAddress = userAddress;
		this.userEmail = userEmail;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword + ", userNumber="
				+ userNumber + ", userAddress=" + userAddress + ", userEmail=" + userEmail + "]";
	}
	public User() {
		super();
	}
	

}
